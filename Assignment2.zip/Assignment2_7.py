def main():
    rows = 5
    for i in range(5):
        for j in range(5):
            print(j+1, end="    ")
        print()


if__name__ = "__main__"
main()