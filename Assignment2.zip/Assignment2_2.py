def main():

    rows = 5

    for i in range(0, rows, 1):
        for j in range(0, rows, 1):
            print("*", end='  ')
        print("\r")  # new line


if__name__ = "__main__"
main()