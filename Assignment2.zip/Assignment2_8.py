def main():
    n = 5
    for i in range(n+1):
        for j in range(1,i+1):
            print(j, end="  ")
        print()


if__name__ = "__main__"
main()